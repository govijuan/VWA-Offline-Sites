<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Braj-Vrindavan Heritage Alliance Guestbook</title>
<meta http-equiv="Content-Type" content="text/html;charset=windows-1250" />
<script type="text/javascript"><!--
function openSmiley()
{
	w=window.open("smileys.php", "smileys", "fullscreen=no,toolbar=no,status=no,menubar=no,scrollbars=yes,resizable=yes,directories=no,location=no,width=500,height=300");
	if(!w.opener)
	{
		w.opener=self;
	}
}
//-->
</script>
<link href="./templates/default/style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<!--CUSTOM HEADER -->
<!--CUSTOM HEADER END -->

<!--HEADER -->
<div id="gbook_header">
        <h1 align="center">Braj-Vrindavan Heritage Alliance Guestbook</h1>
        <!--TOP LINKS -->
        <div id="gbook_top_links">

                <a href="http://bvhalliance.org/">Braj-Vrindavan Heritage Alliance</a> |
		<a href="gbook.php">View guestbook</a> |
		<a href="gbook.php?a=sign">Sign guestbook</a>
		<br class="clear" />

                <span class="gbook_entries_top">Number of entries: 236 Number of pages: 24</span>
		<br class="clear" />
                 <b>1</b>  <a href="gbook.php?page=2">2</a>  <a href="gbook.php?page=3">3</a>  <a href="gbook.php?page=4">4</a>  <a href="gbook.php?page=5">5</a>  <a href="gbook.php?page=6">6</a>  <a href="gbook.php?page=2">Next &rsaquo;</a> <a href="gbook.php?page=24">Last &raquo;</a>
        </div>
        <!--TOP LINKS -->
</div>
<!--HEADER END -->

<!--NOTICE -->
<!--NOTICE END -->

<!--COMMENT BOX -->
<div class="gbook_commentbox">

	<!--LEFT BOX -->
	<div class="gbook_left_box">
	<span class="gbook_submitted">Submitted by</span><br class="clear" />
	<span class="gbook_submitted_by">Name: <b>anonymous</b></span><br class="clear" />
	<span class="gbook_submitted_by">From: germany</span><br class="clear" /><span class="gbook_submitted_by">E-mail: <a href="gbook.php?a=viewEmail&amp;num=0" class="gbook_submitted">Contact</a></span><br class="clear" />	</div>
	<!--LEFT BOX END -->

	<!--RIGHT BOX -->
	<div class="gbook_right_box">
	<span class="gbook_comments">Comments:</span><br class="clear" />
	<span class="gbook_comment">Die Kanzlei TANJA IRION Medienrecht in Hamburg verteidigt Klienten von SCIENTOLOGY wahrscheinlich ist sie selbst der SCIENTOLOGY Organisation sehr nahestehend !</span><br class="clear" />
	<hr align="left" />

		<!--RIGHT BOX 1 -->
		<div class="gbook_right_box_1">
		<span class="gbook_added"><i>Added: June 15, 2013</i></span>
		</div>
		<!--RIGHT BOX 1 END -->

		<!--RIGHT BOX 2 -->
		<div class="gbook_right_box_2" align="right">
		<a href="gbook.php?a=delete&amp;num=0"><img src="./templates/default/images/delete.gif" alt="Delete this entry" class="gbook_nobrd" title="Delete this entry" /></a>
		<a href="gbook.php?a=reply&amp;num=0"><img src="./templates/default/images/reply.gif" alt="Reply to entry" class="gbook_nobrd" title="Reply to entry" /></a>
		<a href="gbook.php?a=viewIP&amp;num=0"><img src="./templates/default/images/ip.gif" alt="View IP address" class="gbook_nobrd" title="View IP address" /></a>
		</div>
		<!--RIGHT BOX 2 END -->
	</div>
	<!--RIGHT BOX END -->

</div>
<!--COMMENT BOX END -->
<!--COMMENT BOX -->
<div class="gbook_commentbox">

	<!--LEFT BOX -->
	<div class="gbook_left_box">
	<span class="gbook_submitted">Submitted by</span><br class="clear" />
	<span class="gbook_submitted_by">Name: <b>Gaura Das</b></span><br class="clear" />
	<span class="gbook_submitted_by">From: Canada</span><br class="clear" /><span class="gbook_submitted_by">E-mail: <a href="gbook.php?a=viewEmail&amp;num=1" class="gbook_submitted">Contact</a></span><br class="clear" />	</div>
	<!--LEFT BOX END -->

	<!--RIGHT BOX -->
	<div class="gbook_right_box">
	<span class="gbook_comments">Comments:</span><br class="clear" />
	<span class="gbook_comment">I am looking for devotee association and appreciate your service to the dhama.</span><br class="clear" />
	<hr align="left" />

		<!--RIGHT BOX 1 -->
		<div class="gbook_right_box_1">
		<span class="gbook_added"><i>Added: April 12, 2012</i></span>
		</div>
		<!--RIGHT BOX 1 END -->

		<!--RIGHT BOX 2 -->
		<div class="gbook_right_box_2" align="right">
		<a href="gbook.php?a=delete&amp;num=1"><img src="./templates/default/images/delete.gif" alt="Delete this entry" class="gbook_nobrd" title="Delete this entry" /></a>
		<a href="gbook.php?a=reply&amp;num=1"><img src="./templates/default/images/reply.gif" alt="Reply to entry" class="gbook_nobrd" title="Reply to entry" /></a>
		<a href="gbook.php?a=viewIP&amp;num=1"><img src="./templates/default/images/ip.gif" alt="View IP address" class="gbook_nobrd" title="View IP address" /></a>
		</div>
		<!--RIGHT BOX 2 END -->
	</div>
	<!--RIGHT BOX END -->

</div>
<!--COMMENT BOX END -->
<!--COMMENT BOX -->
<div class="gbook_commentbox">

	<!--LEFT BOX -->
	<div class="gbook_left_box">
	<span class="gbook_submitted">Submitted by</span><br class="clear" />
	<span class="gbook_submitted_by">Name: <b>Alankara dasa (birth name withheld)</b></span><br class="clear" />
	<span class="gbook_submitted_by">From: United States</span><br class="clear" /><span class="gbook_submitted_by">E-mail: <a href="gbook.php?a=viewEmail&amp;num=2" class="gbook_submitted">Contact</a></span><br class="clear" />	</div>
	<!--LEFT BOX END -->

	<!--RIGHT BOX -->
	<div class="gbook_right_box">
	<span class="gbook_comments">Comments:</span><br class="clear" />
	<span class="gbook_comment">I am a disciple of His Divine Grace Srila A.C. Bhaktivedanta Swami Prabhupada. After meeting Srila Prabhupada in the late 1960s in New York city, my home town, my life changed forever. This was not a sentimental event, but profoundly life changing, and Vrindavan Dham became my new &quot;home town&quot;. Vrindavan Dham is a state of consciousness, and can only be understood by the mercy of the eternal residents. By the mercy of Srimati Radharani I have been able to breathe the mood of this transcendental place on Planet Earth. Hopefully, the current residents will understand their special lives, and protect the purity of Vrindavan? Best to all Bolo Hare Krishna !!!</span><br class="clear" />
	<hr align="left" />

		<!--RIGHT BOX 1 -->
		<div class="gbook_right_box_1">
		<span class="gbook_added"><i>Added: January 26, 2012</i></span>
		</div>
		<!--RIGHT BOX 1 END -->

		<!--RIGHT BOX 2 -->
		<div class="gbook_right_box_2" align="right">
		<a href="gbook.php?a=delete&amp;num=2"><img src="./templates/default/images/delete.gif" alt="Delete this entry" class="gbook_nobrd" title="Delete this entry" /></a>
		<a href="gbook.php?a=reply&amp;num=2"><img src="./templates/default/images/reply.gif" alt="Reply to entry" class="gbook_nobrd" title="Reply to entry" /></a>
		<a href="gbook.php?a=viewIP&amp;num=2"><img src="./templates/default/images/ip.gif" alt="View IP address" class="gbook_nobrd" title="View IP address" /></a>
		</div>
		<!--RIGHT BOX 2 END -->
	</div>
	<!--RIGHT BOX END -->

</div>
<!--COMMENT BOX END -->
<!--COMMENT BOX -->
<div class="gbook_commentbox">

	<!--LEFT BOX -->
	<div class="gbook_left_box">
	<span class="gbook_submitted">Submitted by</span><br class="clear" />
	<span class="gbook_submitted_by">Name: <b>Anupama Braroo</b></span><br class="clear" />
	<span class="gbook_submitted_by">From: Munich, Germany</span><br class="clear" /><span class="gbook_submitted_by">E-mail: <a href="gbook.php?a=viewEmail&amp;num=3" class="gbook_submitted">Contact</a></span><br class="clear" />	</div>
	<!--LEFT BOX END -->

	<!--RIGHT BOX -->
	<div class="gbook_right_box">
	<span class="gbook_comments">Comments:</span><br class="clear" />
	<span class="gbook_comment">Urbanisation in a rural manner is the key...</span><br class="clear" />
	<hr align="left" />

		<!--RIGHT BOX 1 -->
		<div class="gbook_right_box_1">
		<span class="gbook_added"><i>Added: October 10, 2011</i></span>
		</div>
		<!--RIGHT BOX 1 END -->

		<!--RIGHT BOX 2 -->
		<div class="gbook_right_box_2" align="right">
		<a href="gbook.php?a=delete&amp;num=3"><img src="./templates/default/images/delete.gif" alt="Delete this entry" class="gbook_nobrd" title="Delete this entry" /></a>
		<a href="gbook.php?a=reply&amp;num=3"><img src="./templates/default/images/reply.gif" alt="Reply to entry" class="gbook_nobrd" title="Reply to entry" /></a>
		<a href="gbook.php?a=viewIP&amp;num=3"><img src="./templates/default/images/ip.gif" alt="View IP address" class="gbook_nobrd" title="View IP address" /></a>
		</div>
		<!--RIGHT BOX 2 END -->
	</div>
	<!--RIGHT BOX END -->

</div>
<!--COMMENT BOX END -->
<!--COMMENT BOX -->
<div class="gbook_commentbox">

	<!--LEFT BOX -->
	<div class="gbook_left_box">
	<span class="gbook_submitted">Submitted by</span><br class="clear" />
	<span class="gbook_submitted_by">Name: <b>Jim Schwartz</b></span><br class="clear" />
	<span class="gbook_submitted_by">From: United States</span><br class="clear" /><span class="gbook_submitted_by">E-mail: <a href="gbook.php?a=viewEmail&amp;num=4" class="gbook_submitted">Contact</a></span><br class="clear" />	</div>
	<!--LEFT BOX END -->

	<!--RIGHT BOX -->
	<div class="gbook_right_box">
	<span class="gbook_comments">Comments:</span><br class="clear" />
	<span class="gbook_comment">I am glad to see so many organizations working to save Vrindavana and the Yamuna. But I don't see any way for people to donate. Please make a way so people, including us Westerners, can easily donate online. We have the money, you have the dedication.</span><br class="clear" />
	<hr align="left" />

		<!--RIGHT BOX 1 -->
		<div class="gbook_right_box_1">
		<span class="gbook_added"><i>Added: June 20, 2011</i></span>
		</div>
		<!--RIGHT BOX 1 END -->

		<!--RIGHT BOX 2 -->
		<div class="gbook_right_box_2" align="right">
		<a href="gbook.php?a=delete&amp;num=4"><img src="./templates/default/images/delete.gif" alt="Delete this entry" class="gbook_nobrd" title="Delete this entry" /></a>
		<a href="gbook.php?a=reply&amp;num=4"><img src="./templates/default/images/reply.gif" alt="Reply to entry" class="gbook_nobrd" title="Reply to entry" /></a>
		<a href="gbook.php?a=viewIP&amp;num=4"><img src="./templates/default/images/ip.gif" alt="View IP address" class="gbook_nobrd" title="View IP address" /></a>
		</div>
		<!--RIGHT BOX 2 END -->
	</div>
	<!--RIGHT BOX END -->

</div>
<!--COMMENT BOX END -->
<!--COMMENT BOX -->
<div class="gbook_commentbox">

	<!--LEFT BOX -->
	<div class="gbook_left_box">
	<span class="gbook_submitted">Submitted by</span><br class="clear" />
	<span class="gbook_submitted_by">Name: <b>Saloni</b></span><br class="clear" />
	<span class="gbook_submitted_by">From: New York</span><br class="clear" /><span class="gbook_submitted_by">E-mail: <a href="gbook.php?a=viewEmail&amp;num=5" class="gbook_submitted">Contact</a></span><br class="clear" />	</div>
	<!--LEFT BOX END -->

	<!--RIGHT BOX -->
	<div class="gbook_right_box">
	<span class="gbook_comments">Comments:</span><br class="clear" />
	<span class="gbook_comment">
			<br class="clear" />
			<i><a href="gbook.php?a=viewprivate&amp;num=5">Private post. Click to view.</a></i>
			<br class="clear" />
            <br class="clear" />
			</span><br class="clear" />
	<hr align="left" />

		<!--RIGHT BOX 1 -->
		<div class="gbook_right_box_1">
		<span class="gbook_added"><i>Added: March 8, 2011</i></span>
		</div>
		<!--RIGHT BOX 1 END -->

		<!--RIGHT BOX 2 -->
		<div class="gbook_right_box_2" align="right">
		<a href="gbook.php?a=delete&amp;num=5"><img src="./templates/default/images/delete.gif" alt="Delete this entry" class="gbook_nobrd" title="Delete this entry" /></a>
		<a href="gbook.php?a=reply&amp;num=5"><img src="./templates/default/images/reply.gif" alt="Reply to entry" class="gbook_nobrd" title="Reply to entry" /></a>
		<a href="gbook.php?a=viewIP&amp;num=5"><img src="./templates/default/images/ip.gif" alt="View IP address" class="gbook_nobrd" title="View IP address" /></a>
		</div>
		<!--RIGHT BOX 2 END -->
	</div>
	<!--RIGHT BOX END -->

</div>
<!--COMMENT BOX END -->
<!--COMMENT BOX -->
<div class="gbook_commentbox">

	<!--LEFT BOX -->
	<div class="gbook_left_box">
	<span class="gbook_submitted">Submitted by</span><br class="clear" />
	<span class="gbook_submitted_by">Name: <b>Greg</b></span><br class="clear" />
	<span class="gbook_submitted_by">From: USA</span><br class="clear" /><span class="gbook_submitted_by">E-mail: <a href="gbook.php?a=viewEmail&amp;num=6" class="gbook_submitted">Contact</a></span><br class="clear" />	</div>
	<!--LEFT BOX END -->

	<!--RIGHT BOX -->
	<div class="gbook_right_box">
	<span class="gbook_comments">Comments:</span><br class="clear" />
	<span class="gbook_comment">It is about time that we pay attention to our heritage. India is respected all over the world for it's centuries old values and they are evident in the legacy that has been left behind by our Great Acharyas. Vrindaban is not a commercial city or a resort. This is a place of serious devotion seekers. We should not leave any stone unturned in order to preserve the sanctity of the place. These are the grounds where Lord has His pastimes. The residents of Vrindaban are fortunate to live there and they should be educated in keeping it cleaner than they found it. <br />We copy the Western countries in technology but we don't know how much is done in the Western countries to keep their countries clean and safe. Let's learn it from the Westerners.</span><br class="clear" />
	<hr align="left" />

		<!--RIGHT BOX 1 -->
		<div class="gbook_right_box_1">
		<span class="gbook_added"><i>Added: November 22, 2010</i></span>
		</div>
		<!--RIGHT BOX 1 END -->

		<!--RIGHT BOX 2 -->
		<div class="gbook_right_box_2" align="right">
		<a href="gbook.php?a=delete&amp;num=6"><img src="./templates/default/images/delete.gif" alt="Delete this entry" class="gbook_nobrd" title="Delete this entry" /></a>
		<a href="gbook.php?a=reply&amp;num=6"><img src="./templates/default/images/reply.gif" alt="Reply to entry" class="gbook_nobrd" title="Reply to entry" /></a>
		<a href="gbook.php?a=viewIP&amp;num=6"><img src="./templates/default/images/ip.gif" alt="View IP address" class="gbook_nobrd" title="View IP address" /></a>
		</div>
		<!--RIGHT BOX 2 END -->
	</div>
	<!--RIGHT BOX END -->

</div>
<!--COMMENT BOX END -->
<!--COMMENT BOX -->
<div class="gbook_commentbox">

	<!--LEFT BOX -->
	<div class="gbook_left_box">
	<span class="gbook_submitted">Submitted by</span><br class="clear" />
	<span class="gbook_submitted_by">Name: <b>nishant vashisht</b></span><br class="clear" />
	<span class="gbook_submitted_by">From: new delhi / vrindavan</span><br class="clear" /><span class="gbook_submitted_by">E-mail: <a href="gbook.php?a=viewEmail&amp;num=7" class="gbook_submitted">Contact</a></span><br class="clear" />	</div>
	<!--LEFT BOX END -->

	<!--RIGHT BOX -->
	<div class="gbook_right_box">
	<span class="gbook_comments">Comments:</span><br class="clear" />
	<span class="gbook_comment">haribol !<br /><br />best wishes for the best endeavours !!</span><br class="clear" />
	<hr align="left" />

		<!--RIGHT BOX 1 -->
		<div class="gbook_right_box_1">
		<span class="gbook_added"><i>Added: September 25, 2010</i></span>
		</div>
		<!--RIGHT BOX 1 END -->

		<!--RIGHT BOX 2 -->
		<div class="gbook_right_box_2" align="right">
		<a href="gbook.php?a=delete&amp;num=7"><img src="./templates/default/images/delete.gif" alt="Delete this entry" class="gbook_nobrd" title="Delete this entry" /></a>
		<a href="gbook.php?a=reply&amp;num=7"><img src="./templates/default/images/reply.gif" alt="Reply to entry" class="gbook_nobrd" title="Reply to entry" /></a>
		<a href="gbook.php?a=viewIP&amp;num=7"><img src="./templates/default/images/ip.gif" alt="View IP address" class="gbook_nobrd" title="View IP address" /></a>
		</div>
		<!--RIGHT BOX 2 END -->
	</div>
	<!--RIGHT BOX END -->

</div>
<!--COMMENT BOX END -->
<!--COMMENT BOX -->
<div class="gbook_commentbox">

	<!--LEFT BOX -->
	<div class="gbook_left_box">
	<span class="gbook_submitted">Submitted by</span><br class="clear" />
	<span class="gbook_submitted_by">Name: <b>Subal Sakha das</b></span><br class="clear" />
	<span class="gbook_submitted_by">From: FL, LA,NY</span><br class="clear" /><span class="gbook_submitted_by">E-mail: <a href="gbook.php?a=viewEmail&amp;num=8" class="gbook_submitted">Contact</a></span><br class="clear" />	</div>
	<!--LEFT BOX END -->

	<!--RIGHT BOX -->
	<div class="gbook_right_box">
	<span class="gbook_comments">Comments:</span><br class="clear" />
	<span class="gbook_comment">Hopefully India will join the rest of the people of the world who want to make a difference to save the planet earth. After all this is the place that God gave you and your families to live.<br />Show some respect for the planet that you are residing on.....have respect for God &amp; yourselves. Think about your children and make this world a better place for them to live. Make a difference in the world you live in. Protect her and give back to her. The earth provides everything for us to live. Show some respect India for the land you live on. Hopefully Indian people will read this, accept education,and understand the importance of protecting the earth.</span><br class="clear" />
	<hr align="left" />

		<!--RIGHT BOX 1 -->
		<div class="gbook_right_box_1">
		<span class="gbook_added"><i>Added: September 5, 2010</i></span>
		</div>
		<!--RIGHT BOX 1 END -->

		<!--RIGHT BOX 2 -->
		<div class="gbook_right_box_2" align="right">
		<a href="gbook.php?a=delete&amp;num=8"><img src="./templates/default/images/delete.gif" alt="Delete this entry" class="gbook_nobrd" title="Delete this entry" /></a>
		<a href="gbook.php?a=reply&amp;num=8"><img src="./templates/default/images/reply.gif" alt="Reply to entry" class="gbook_nobrd" title="Reply to entry" /></a>
		<a href="gbook.php?a=viewIP&amp;num=8"><img src="./templates/default/images/ip.gif" alt="View IP address" class="gbook_nobrd" title="View IP address" /></a>
		</div>
		<!--RIGHT BOX 2 END -->
	</div>
	<!--RIGHT BOX END -->

</div>
<!--COMMENT BOX END -->
<!--COMMENT BOX -->
<div class="gbook_commentbox">

	<!--LEFT BOX -->
	<div class="gbook_left_box">
	<span class="gbook_submitted">Submitted by</span><br class="clear" />
	<span class="gbook_submitted_by">Name: <b>kirtan.ddasi</b></span><br class="clear" />
	<span class="gbook_submitted_by">From: colombia- south america</span><br class="clear" /><span class="gbook_submitted_by">E-mail: <a href="gbook.php?a=viewEmail&amp;num=9" class="gbook_submitted">Contact</a></span><br class="clear" />	</div>
	<!--LEFT BOX END -->

	<!--RIGHT BOX -->
	<div class="gbook_right_box">
	<span class="gbook_comments">Comments:</span><br class="clear" />
	<span class="gbook_comment">Sign the petition ! the petition for vrindavan</span><br class="clear" />
	<hr align="left" />

		<!--RIGHT BOX 1 -->
		<div class="gbook_right_box_1">
		<span class="gbook_added"><i>Added: August 24, 2010</i></span>
		</div>
		<!--RIGHT BOX 1 END -->

		<!--RIGHT BOX 2 -->
		<div class="gbook_right_box_2" align="right">
		<a href="gbook.php?a=delete&amp;num=9"><img src="./templates/default/images/delete.gif" alt="Delete this entry" class="gbook_nobrd" title="Delete this entry" /></a>
		<a href="gbook.php?a=reply&amp;num=9"><img src="./templates/default/images/reply.gif" alt="Reply to entry" class="gbook_nobrd" title="Reply to entry" /></a>
		<a href="gbook.php?a=viewIP&amp;num=9"><img src="./templates/default/images/ip.gif" alt="View IP address" class="gbook_nobrd" title="View IP address" /></a>
		</div>
		<!--RIGHT BOX 2 END -->
	</div>
	<!--RIGHT BOX END -->

</div>
<!--COMMENT BOX END -->
<div class="clear"></div><div style="text-align:center">Powered by <a href="http://www.phpjunkyard.com/php-guestbook-script.php"  target="_blank" title="Guestbook">PHP Guestbook</a> 1.7 from <a href="http://www.phpjunkyard.com/"  target="_blank" title="Free PHP Scripts">PHP Scripts</a></div><div class="clear">&nbsp;</div>

<div align="center" class="gbook_bottom">
 <b>1</b>  <a href="gbook.php?page=2">2</a>  <a href="gbook.php?page=3">3</a>  <a href="gbook.php?page=4">4</a>  <a href="gbook.php?page=5">5</a>  <a href="gbook.php?page=6">6</a>  <a href="gbook.php?page=2">Next &rsaquo;</a> <a href="gbook.php?page=24">Last &raquo;</a></div>

<!--NOSPAM BANNER -->
<!--NOSPAM BANNER END -->

<!--CUSTOM FOOTER -->
<!--CUSTOM FOOTER END -->

</body>
</html>
