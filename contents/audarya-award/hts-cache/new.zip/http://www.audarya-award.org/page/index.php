<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-gb" lang="en-gb" >
<head>
<meta name="verify-v1" content="zTrxPn9TAH0VCOGGrm7+la6bQnak4OWrntT9iOrcvLE=" />
<meta name="google-site-verification" content="YHUbSSy1LyCzKvRV7l50bhoCNGrE7GM2f94MrVPQVpw" />

  <base href="http://www.audarya-award.org/page/index.php" />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="Audarya, Award, Vaisnava, Vaisnavism, Krishna, Govinda Gopala" />
  <meta name="description" content="Audarya Award page" />
  <meta name="generator" content="Joomla! 1.5 - Open Source Content Management" />
  <title>Welcome</title>
  <script type="text/javascript" src="/page/media/system/js/mootools.js"></script>
  <script type="text/javascript" src="/page/media/system/js/caption.js"></script>
  <script src="http://www.audarya-award.org/page/plugins/content/1pixelout/audio-player.js" type="text/javascript"></script>
  <!-- JoomlaWorks "AllVideos" Plugin (v2.5.3) starts here -->

	<style type="text/css" media="all">
		@import "http://www.audarya-award.org/page/plugins/content/jw_allvideos/templates/Default/template_css.css";
	</style>
			
	<script type="text/javascript" src="http://www.audarya-award.org/page/plugins/content/jw_allvideos/players/silverlight.js"></script>
	<script type="text/javascript" src="http://www.audarya-award.org/page/plugins/content/jw_allvideos/players/wmvplayer.js"></script>
	<script type="text/javascript" src="http://www.audarya-award.org/page/plugins/content/jw_allvideos/players/AC_QuickTime.js"></script>
			
<!-- JoomlaWorks "AllVideos" Plugin (v2.5.3) ends here -->


<!-- WIDELAYOUT:OFF  -->

<link rel="stylesheet" href="/page/templates/system/css/system.css" type="text/css" />

<link rel="stylesheet" href="/page/templates/m-flower-2/css/template.css" type="text/css" />

<!--[if lte IE 6]>
<link rel="stylesheet" href="/page/templates/m-flower-2/css/ie7.css" type="text/css" />
<![endif]-->

</head>
<body>
	<div id="page_bg">
		<!--topmenu start-->
		<div class="pill_m">
			<div id="pillmenu">
			<table cellspacing="0" cellpadding="0" style="margin: 0 auto;">
				<tr><td>
				<table width="100%" border="0" cellpadding="0" cellspacing="1"><tr><td nowrap="nowrap"><a href="/page/home" class="mainlevel" id="active_menu">Home</a><a href="/page/seach/%252F" class="mainlevel" >Search</a><a href="/page/add-new" class="mainlevel" >Add New</a><a href="/page/register" class="mainlevel" >Register</a><a href="/page/log-in" class="mainlevel" >Log In</a><a href="/page/help" class="mainlevel" >Help</a></td></tr></table>
				</td></tr>
			</table>
			</div>
		</div>	
		<div class="clr"></div>
		<!--topmenu end-->
		
		<!--header start -->
		<div id="header">
			<div id="logo">
				<table cellspacing="0" cellpadding="0" style="width: 900px; height: 140px; text-align: center; margin: 0 auto;">
					<tr><td style="text-align: center; vertical-align: middle;">
						<a href="/page/index.php"> </a>
					</td></tr>
				</table>
			</div>	
			<div class="clr"></div>
		</div>
		<div class="clr"></div>
		<!--header end -->
		
		<!--center start-->
		<div class="center">
			<div id="wrapper">
				<div id="content">
											<div id="leftcolumn">	
									<div class="module">
			<div>
				<div>
					<div>
													<h3>Category</h3>
											
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr ><td><a href="/page/books" class="mainlevel" >Books</a></td></tr>
<tr ><td><a href="/page/movie" class="mainlevel" >Movie</a></td></tr>
<tr ><td><a href="/page/architecture" class="mainlevel" >Architecture</a></td></tr>
<tr ><td><a href="/page/music" class="mainlevel" >Music</a></td></tr>
<tr ><td><a href="/page/community-project" class="mainlevel" >Community project</a></td></tr>
<tr ><td><a href="/page/dharma-presentation" class="mainlevel" >Dharma presentation</a></td></tr>
<tr ><td><a href="/page/dham-seva" class="mainlevel" >Dham seva</a></td></tr>
<tr ><td><a href="/page/journal" class="mainlevel" >Journal</a></td></tr>
<tr ><td><a href="/page/art-contribution" class="mainlevel" >Art Contribution</a></td></tr>
<tr ><td><a href="/page/home-page" class="mainlevel" >Home Page</a></td></tr>
<tr ><td><a href="/page/innovative" class="mainlevel" >Innovative</a></td></tr>
<tr ><td><a href="/page/charity" class="mainlevel" >Charity</a></td></tr>
<tr ><td><a href="/page/unity" class="mainlevel" >Efforts for Unity</a></td></tr>
<tr ><td><a href="/page/applied-ecology" class="mainlevel" >Applied Ecology</a></td></tr>
<tr ><td><a href="/page/distribution" class="mainlevel" >Distribution</a></td></tr>
</table>					</div>
				</div>
			</div>
		</div>
			<div class="module_menu">
			<div>
				<div>
					<div>
													<h3>Content</h3>
											<ul id="mainlevel"><li><a href="/page/search/%252F" class="mainlevel" >Search</a></li><li><a href="/page/add-new" class="mainlevel" >Add New</a></li><li><a href="/page/help" class="mainlevel" >Help</a></li></ul>					</div>
				</div>
			</div>
		</div>
			<div class="module_blogfeed">
			<div>
				<div>
					<div>
													<h3>Blog</h3>
											<div style="direction: ltr; text-align: left ! important">
	<table cellpadding="0" cellspacing="0" class="moduletable_blogfeed">
			<tr>
			<td>
				<strong>
					<a href="http://audaryaawards.blogspot.com/" target="_blank">
						Audarya Awards - the award of Universal Love</a>
				</strong>
			</td>
		</tr>
			<tr>
		<td>
			<ul class="newsfeed_blogfeed"  >
							<li>
									<a href="http://audaryaawards.blogspot.com/2011/11/sripad-bhaktivedanta-varaha-maharaja.html" target="_blank">
					Sripad Bhaktivedanta Varaha Maharaja - BhagavadGita.org</a>
								</li>
								<li>
									<a href="http://audaryaawards.blogspot.com/2011/02/bhaktisiddhanta-das.html" target="_blank">
					BHAKTISIDDHANTA DAS</a>
								</li>
								<li>
									<a href="http://audaryaawards.blogspot.com/2011/01/braj-foundation-best-restoration-of.html" target="_blank">
					BRAJ FOUNDATION - The best restoration of holy place Brahmakunda</a>
								</li>
								<li>
									<a href="http://audaryaawards.blogspot.com/2011/01/kurma-rupa-dasa-cow-protection-care-for.html" target="_blank">
					KURMA RUPA DASA - Cow protection &quot;Care for Cows&quot;</a>
								</li>
								<li>
									<a href="http://audaryaawards.blogspot.com/2011/01/akshaya-patra-foundation-charity-for.html" target="_blank">
					MADHU PANDIT DAS AND TEAM - The best animated movie: Little Krishna</a>
								</li>
								<li>
									<a href="http://audaryaawards.blogspot.com/2011/01/imlitala-siddhapeeth-beautiful.html" target="_blank">
					IMLITALA SIDDHAPEETH - Beautiful decoration and art</a>
								</li>
								<li>
									<a href="http://audaryaawards.blogspot.com/2011/01/sandipani-muni-school.html" target="_blank">
					SANDIPANI MUNI SCHOOL - Education for the poorest of the poor</a>
								</li>
								<li>
									<a href="http://audaryaawards.blogspot.com/2011/01/syamarani-dd.html" target="_blank">
					SYAMARANI DD - Beautiful windows into the spiritual realm</a>
								</li>
							</ul>
		</td>
		</tr>
	</table>
</div>
					</div>
				</div>
			</div>
		</div>
	
						</div>
												
												<div id="maincolumn">
													<div class="nopad">			
								
																	
<table class="contentpaneopen">



<tr>
<td valign="top">
<p style="text-align: center;"> </p>
<p style="text-align: center;"><span style="font-size: 12pt;"><span style="color: #993300;"><em>Welcom On Audarya Award website!</em></span></span></p>
<p style="text-align: center;"> </p>
<p style="text-align: center;">

<!-- JoomlaWorks "AllVideos" Plugin (v2.5.3) starts here -->
<span class="allvideos">
<span style="width:400px;height:300px;" class="allvideos_player" title="JoomlaWorks AllVideos Player">
	<object type="application/x-shockwave-flash" style="width:400px;height:300px;" data="http://www.audarya-award.org/page/plugins/content/jw_allvideos/players/mediaplayer_4.0.46.swf">
		<param name="movie" value="http://www.audarya-award.org/page/plugins/content/jw_allvideos/players/mediaplayer_4.0.46.swf" />
		<param name="quality" value="high" />
		<param name="wmode" value="transparent" />
		<param name="bgcolor" value="" />
		<param name="autoplay" value="false" />
		<param name="allowfullscreen" value="true" />
		<param name="allowscriptaccess" value="always" />
		<param name="flashvars" value="file=http://www.audarya-award.org/page/images/stories/videos/audarya1.flv&amp;image=http://www.audarya-award.org/page/images/stories/videos/audarya1.jpg&amp;autostart=false&amp;fullscreen=true" />
	</object>
</span>
</span>
<!-- JoomlaWorks "AllVideos" Plugin (v2.5.3) ends here -->

</p>
<p style="text-align: center;"> </p>
<p style="text-align: center;"><strong>The first news about Audarya Award</strong></p>
<p style="text-align: center;">The World Vaisnava Association Visva Vaisnava Raj SabhaAnnouncing:</p>
<p style="text-align: center;"> </p>
<p style="text-align: center;"><span style="font-size: 14pt;"><strong>The Audarya Award</strong></span></p>
<p> </p>
<p>Audarya means the highest magnanimity for the fallen souls. This is the spirit of Sri Chaitanya Mahaprabhu as expressed by Srila Rupa Goswami. This name was chosen for the Audarya awards since the main consideration for the choice of the winners will be the effecting of the contribution to help uplift the fallen souls from the kingdom of Maya.</p>
<p>The Vrindavan Institute for Vaisnava Culture and Studies has sponsored for all the Vaisnavas in the world either affiliated or passive members of the World Vaisnava Association to participate in the By yearly competition for the best contributions to the field of Vaisnava services.</p>
<p>The following subjects will be evaluated to choose the best contributions to the different fields.The awards will be given by a board of five Sannyasys from five different missions of the WVA-VVRS The Audarya award for the best</p>
<p> </p>
<p style="padding-left: 30px;">1. <a href="/page/books">Book publication of Vaisnava Literature in any language.</a><br /> 2. <a href="/page/movie">Movie production with Vaisnava message.</a><br /> 3. <a href="/page/architecture">Temple construction.</a><br /> 4. <a href="/page/music">Music recording of traditional style.</a><br /> 5. <a href="/page/music">Music recording of novel style.</a><br /> 6. <a href="/page/community-project">Vaisnava Community.( By design, Worship and preaching projects)</a><br /> 7. <a href="/page/dharma-presentation">Drama presentation. ( script and production)</a><br /> 8. <a href="/page/dham-seva">Dham seva.(Activities to improve the situation of the holy Dhamas)</a><br /> 9. <a href="/page/journal">Vaisnava journal</a><br /> 10. <a href="/page/art-contribution">Art Contribution (Sculptures, Paintings or Installations, Festival carts.</a><br /> 11. <a href="/page/home-page">Home page on the Internet</a><br /> 12. <a href="/page/innovative">Innovative Contribution to Preaching the glories of Vaisnavism.</a><br /> 13. <a href="/page/charity">Vaisnava Charity.</a><br /> 14. <a href="/page/unity">Effort for Vaisnava unity.</a><br /> 15. <a href="/page/applied-ecology">Applied Ecology in a Vaisnava project.</a><br /> 16. <a href="/page/distribution">Distributor of Vaisnava literature.</a></p>
<p> </p>
<p>The entries can be made of contributions made in any language. Only a briefdescription of the service should be made in English with the entry. Tapes, Photos, Books, Description or Video should accompany any entry. If the award goes to an organization rather then an individual Vaisnava, they shall choose who will receive the award on their behalf.</p>
<p>Please send all entries to:</p>
<p> </p>
<p style="padding-left: 30px;"><em>World Vaisnava association<br /> Audarya Awards<br /> Vansi Kunja<br /> Gopesvara Road 146<br /> Vrindavan Dham Mohalla Pin 281121<br /> District Mathura UP  India</em></p>
<p> </p>
<p>The first year where the Awards are given is the year 2000 at Kartika Vrindavan. Entries must arrive by Gour Purnima of the year 2000.Entries do not have to be recently produced, but can be entered only once into the evaluation. Anyone can nominate a contribution.</p>
<p>Each Audarya Award winner will get:</p>
<p>A certificate. A bronze plaque with Sri Sri Gour Nitai embossed and the inscription of the winner's name and Seva contribution. An undisclosed gift. A one month free Vrindavan parikrama retreat with full food and board in Vrindavan in the Vrinda Kunja Guesthouse. A presentation in the Visva vaisnava Raj Sabha magazin of the contribution. A free Home page of the award winning contribution on the Internet designed by the WVA-VVRS Internet committee or by the producer himself (under the WVA-VVRS domain). All award winners and other nominated projects will appear in the list "The best of Vaisnavism" on the Home page of the World Vaisnava Association.</p>
<p>Hoping to contribute with these awards to unify the Vaisnava world and to glorify the servant of Guru Krishna and humanity this new project is offered to the World Vaisnava association by the members of the Vrinda family.</p>
<p> </p></td>
</tr>

</table>
<span class="article_separator">&nbsp;</span>

															</div>
						</div>

																		<div id="rightcolumn" style="float:right;">
									<div class="module_loginwin">
			<div>
				<div>
					<div>
													<h3>Login</h3>
											<form action="/page/index.php" method="post" name="login" id="form-login" >
		<fieldset class="input">
	<p id="form-login-username">
		<label for="modlgn_username">Username</label><br />
		<input id="modlgn_username" type="text" name="username" class="inputbox" alt="username" size="18" />
	</p>
	<p id="form-login-password">
		<label for="modlgn_passwd">Password</label><br />
		<input id="modlgn_passwd" type="password" name="passwd" class="inputbox" size="18" alt="password" />
	</p>
		<p id="form-login-remember">
		<label for="modlgn_remember">Remember Me</label>
		<input id="modlgn_remember" type="checkbox" name="remember" class="inputbox" value="yes" alt="Remember Me" />
	</p>
		<input type="submit" name="Submit" class="button" value="Login" />
	</fieldset>
	<ul>
		<li>
			<a href="/page/component/user/reset">
			Forgot your password?</a>
		</li>
		<li>
			<a href="/page/component/user/remind">
			Forgot your username?</a>
		</li>
				<li>
			<a href="/page/component/user/register">
				Create an account</a>
		</li>
			</ul>
	
	<input type="hidden" name="option" value="com_user" />
	<input type="hidden" name="task" value="login" />
	<input type="hidden" name="return" value="L3BhZ2UvaW5kZXgucGhw" />
	<input type="hidden" name="9b013749617d783593b52e81287d779f" value="1" /></form>
					</div>
				</div>
			</div>
		</div>
			<div class="module">
			<div>
				<div>
					<div>
													<h3>Websites</h3>
											<p style="text-align: center;"><a href="http://audaryaawards.blogspot.com/"><img src="/page/images/stories/logos/audarya-blogspot-logo.jpg" alt="" /></a></p>
<div style="text-align: center;">&nbsp;</div>
<div style="text-align: center;"><a href="http://www.vina.cc"><img src="/page/images/stories/logos/vina-cc.jpg" alt="" /></a></div>
<div style="text-align: center;">&nbsp;</div>
<div style="text-align: center;"><a href="http://www.wva-vvrs.org"><img src="/page/images/stories/logos/wva.jpg" alt="" /></a></div>					</div>
				</div>
			</div>
		</div>
									
						</div>
										<div class="clr"></div>
				</div>		
			</div>
		</div>
		<!--center end-->
		
		<!--footer start-->
		<div id="footer">
			<div id="sgf">
				<div>
					<div style="text-align: center; padding: 24px 0 0;">
											</div> 
				</div>
			</div>
		</div>
		<!--footer end-->
		
	</div>	
	
	
		
</body>
</html>
